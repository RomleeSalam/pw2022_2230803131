
<?php
$mahasiswa = ["Joni","123456"."Sistem informasi","dyangmail.com"];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Document</title>
    </head>
    <body>
        <h1>Daftar mahasiswa </h1>
        <ul>
            <l1>Joni</l1>
            <l1>123456</l1>
            <l1>Sistem informasi</l1>
            <l1>dyangmail.com</l1>
        </ul>
    </body>
</html>
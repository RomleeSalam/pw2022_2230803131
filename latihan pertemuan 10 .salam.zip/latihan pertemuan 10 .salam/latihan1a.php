<?php

$topi = "topi saya bundar";
$bundar = "bundar topi saya";

echo $topi.", ".$bundar;

?>
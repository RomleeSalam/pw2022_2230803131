<?php
$nrp = "173040888";
$nama = "lorem ipsum";
$umur = 20;
$nilai = 75.75;

echo "Nrp   : ". $nrp . "</br>";
echo "Nama  : $nama .</br>";
print "Umur  : ". $umur; print "</br>";

printf ("Nilai  : %.3f</br>", $nilai);
?>
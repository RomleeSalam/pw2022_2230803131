<?php
    define ("TEST", "testing konstanta"); 
    define ("TEST", "test2");
?>
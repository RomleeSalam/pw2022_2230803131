<?php
    echo "<h2>Pengulangan 1 - 10</h2>";
    $i = 1;
    do{
        echo $i."<br />";
        $i++;
    }
    while ($i<=10);
?>
<html> 
<head> 
<title>Contoh Echo dan Print</title> 
</head> 
<body> 
    <?php 
        echo "teks ini dengan perintah echo"; 
    ?> 
    <br /> 
    <?php 
        print "teks ini dengan perintah print"; 
    ?> 
<br /> 
</body> 
</html>
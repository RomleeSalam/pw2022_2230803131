<?php
    echo "<h2>Pengulangan 1 - 10</h2>";
    for ($i=1; $i<=10; $i++){
        echo $i."<br />";
    }
    
?>
<html>
<body>
    <?php
        echo "Hello world"; 
        print "Sedang belajar PHP";
    ?>
</body>
</html>





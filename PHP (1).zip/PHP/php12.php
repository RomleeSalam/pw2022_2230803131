<?php
    echo "<h2>Pengulangan 1 - 10</h2>";
    $i=1;
    while ($i<=10){
        echo $i."<br />";
        $i++;
    }  
?>
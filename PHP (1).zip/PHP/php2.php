<?php
    echo "<html>
            <body>
                Hello world
                Sedang belajar PHP
             </body>
          </html>";
?>
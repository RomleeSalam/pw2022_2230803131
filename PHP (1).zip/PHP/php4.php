<html>
    <head>
        <title>Contoh Echo dan Print</title>
    </head>
    <body>
        <?php
            echo "<h3>CETAK VARIABEL</h3>";

            $a = 1000;
            
            echo "Isi variabel \$a adalah $a"; 
            echo "<br />";
            echo 'Isi variabel $a adalah '.$a;
        ?>
    </body>
</html>
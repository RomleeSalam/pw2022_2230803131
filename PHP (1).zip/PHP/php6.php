<?php
$userid = "informatika";
if ($userid == "informatika") 
    {
        echo "benar"; 
    }
    else 
    { 
        echo "salah"; 
    }
?>
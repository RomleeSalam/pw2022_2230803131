<?php
    $greeting = (date ("H") <= 12)? "Selamat Pagi" : "Selamat Siang";
    echo $greeting;
?>